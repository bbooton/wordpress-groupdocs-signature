=== GroupDocs Signature ===
Contributors: GroupDocs Team
Tags: contract management software
Author URI: http://groupdocs.com
Requires at least: 2.8
Tested up to: 3.4.1
Stable tag: trunk
License: GPLv2



== Description ==
GroupDocs is a next generation Document Management solution that makes it easier for businesses to collaborate, share and work with documents online. So, organise, view, annotate, compare, assemble and share all your documents with WordPress


== Installation ==

1. Upload the entire `groupdocs-signature` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the `Plugins` menu in WordPress.
3. Done.

Upload the documents to your GroupDocs account. Use the GroupDocs Signature button in the Visual editor to build the appropriate shortcode by copy&pasting the document groupdocs.com link.



== Frequently Asked Questions ==

= How can I get detailed help =
For further help you may choose any of following options:

* You can also contact us by various means as mentioned on our [Contact Us](http://groupdocs.com/about/contact/) page.


== Changelog ==

= 1.0 =
* Initial release.
