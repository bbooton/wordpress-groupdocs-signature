edButtons[edButtons.length] =
new edButton('gd_signature'
	,'gd_signature'
	,'[grpdocssignature form="'
	,'" width="500" height="600"]'
	,'1'
);